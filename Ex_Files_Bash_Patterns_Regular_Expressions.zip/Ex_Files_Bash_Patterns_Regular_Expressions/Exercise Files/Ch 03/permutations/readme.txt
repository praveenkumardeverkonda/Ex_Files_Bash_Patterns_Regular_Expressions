The brace script produces unique combinations but reuses letters. Run by typing ./permu-braces.sh permudata.txt
The pattern substitution script produces actual permutations. Run by typing ./permu-patsub.sh permudata.txt
